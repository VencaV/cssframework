/*******************************************************************************

  Main JavaScript
  Author: Medio Interactive (http://medio.cz/)

*******************************************************************************/

$(function() {
	
	// Toggle menu
	$('.toggle-menu').on('click', function(e) {
		e.preventDefault();
		$('#navigation').toggle();
	});
	
});